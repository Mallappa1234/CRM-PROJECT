from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Sum, Q

from customers.models import Customer
from sales.models import Lead, Opportunity
from support.models import Ticket

@login_required
def index(request):
    # Get current user profile to determine role permissions
    user_profile = request.user.userprofile
    
    # Customer stats
    total_customers = Customer.objects.count()
    active_customers = Customer.objects.filter(status=Customer.STATUS_ACTIVE).count()
    
    # Lead stats
    total_leads = Lead.objects.count()
    new_leads = Lead.objects.filter(status=Lead.STATUS_NEW).count()
    qualified_leads = Lead.objects.filter(status=Lead.STATUS_QUALIFIED).count()
    
    # Opportunity stats
    total_opportunities = Opportunity.objects.count()
    total_opportunity_value = Opportunity.objects.aggregate(total=Sum('value'))['total'] or 0
    
    # Support stats
    open_tickets = Ticket.objects.filter(status__in=[Ticket.STATUS_OPEN, Ticket.STATUS_IN_PROGRESS]).count()
    urgent_tickets = Ticket.objects.filter(priority=Ticket.PRIORITY_URGENT).count()
    
    # Get user-specific items
    if user_profile.is_sales() or user_profile.is_admin():
        assigned_leads = Lead.objects.filter(assigned_to=request.user).count()
        assigned_opportunities = Opportunity.objects.filter(assigned_to=request.user).count()
    else:
        assigned_leads = 0
        assigned_opportunities = 0
        
    if user_profile.is_support() or user_profile.is_admin():
        assigned_tickets = Ticket.objects.filter(assigned_to=request.user).count()
    else:
        assigned_tickets = 0
    
    context = {
        'user_profile': user_profile,
        'total_customers': total_customers,
        'active_customers': active_customers,
        'total_leads': total_leads,
        'new_leads': new_leads,
        'qualified_leads': qualified_leads,
        'total_opportunities': total_opportunities,
        'total_opportunity_value': total_opportunity_value,
        'open_tickets': open_tickets,
        'urgent_tickets': urgent_tickets,
        'assigned_leads': assigned_leads,
        'assigned_opportunities': assigned_opportunities,
        'assigned_tickets': assigned_tickets,
    }
    
    return render(request, 'dashboard/index.html', context)
