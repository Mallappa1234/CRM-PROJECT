from django import forms
from django.contrib.auth.models import User
from .models import Ticket, TicketReply, TicketCategory
from customers.models import Customer
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, PasswordResetForm, SetPasswordForm
from .models import UserProfile

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    role = forms.ChoiceField(choices=UserProfile.ROLE_CHOICES)
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2', 'role']
    def save(self, commit=True):
        user = super(UserCreationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        
        if commit:
            user.save()
            # Create UserProfile only if it doesn't exist already
            UserProfile.objects.get_or_create(
                user=user,
                defaults={'role': self.cleaned_data['role']}
            )
        return user
class CustomAuthenticationForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-input'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-input'}))
class CustomPasswordResetForm(PasswordResetForm):
    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-input'}))
class CustomSetPasswordForm(SetPasswordForm):
    new_password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-input'}))
    new_password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-input'}))
class UserProfileForm(forms.ModelForm):
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    email = forms.EmailField(required=True)
    class Meta:
        model = UserProfile
        fields = ['role', 'phone', 'address']
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        # Pre-fill user data if available
        if self.user:
            self.fields['first_name'].initial = self.user.first_name
            self.fields['last_name'].initial = self.user.last_name
            self.fields['email'].initial = self.user.email
class TicketForm(forms.ModelForm):
    customer = forms.ModelChoiceField(
        queryset=Customer.objects.filter(status='active'),
        required=True
    )
    assigned_to = forms.ModelChoiceField(
        queryset=User.objects.filter(userprofile__role__in=['admin', 'support']),
        required=False
    )
    
    class Meta:
        model = Ticket
        fields = ['subject', 'customer', 'category', 'priority', 'status', 'description', 'assigned_to']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }

class TicketReplyForm(forms.ModelForm):
    class Meta:
        model = TicketReply
        fields = ['message', 'is_internal']
        widgets = {
            'message': forms.Textarea(attrs={'rows': 3}),
        }

class TicketUpdateForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ['status', 'priority', 'assigned_to']

class TicketSearchForm(forms.Form):
    search = forms.CharField(required=False, label='', 
                           widget=forms.TextInput(attrs={'placeholder': 'Search tickets...'}))
    status = forms.ChoiceField(required=False, choices=[('', 'All Statuses')] + list(Ticket.STATUS_CHOICES))
    priority = forms.ChoiceField(required=False, choices=[('', 'All Priorities')] + list(Ticket.PRIORITY_CHOICES))
    category = forms.ModelChoiceField(
        queryset=TicketCategory.objects.all(),
        required=False,
        empty_label="All Categories"
    )