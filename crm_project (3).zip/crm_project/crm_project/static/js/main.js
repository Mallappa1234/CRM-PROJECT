// Mobile sidebar toggle
document.addEventListener('DOMContentLoaded', function() {
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
        const logoutLink = document.querySelector('a[href*="accounts/logout"]');
    if (logoutLink) {
        logoutLink.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = '/accounts/logout/';
            // Add a fallback redirect after a short delay
            setTimeout(function() {
                window.location.href = '/accounts/login/';
            }, 500);
        });
    }
    
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
        });
    }
    
    // Automatically dismiss messages after 5 seconds
    const messages = document.querySelectorAll('.message');
    if (messages.length > 0) {
        setTimeout(function() {
            messages.forEach(function(message) {
                message.style.opacity = '0';
                setTimeout(function() {
                    message.style.display = 'none';
                }, 500);
            });
        }, 5000);
    }
    
    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(function(field) {
                if (!field.value.trim()) {
                    isValid = false;
                    // Add error styling
                    field.classList.add('error');
                    // Get the field label or use field name
                    const fieldName = field.previousElementSibling ? 
                                     field.previousElementSibling.textContent : 
                                     field.getAttribute('name');
                    
                    // Create error message if it doesn't exist
                    let errorMsg = field.nextElementSibling;
                    if (!errorMsg || !errorMsg.classList.contains('error-message')) {
                        errorMsg = document.createElement('div');
                        errorMsg.classList.add('error-message');
                        errorMsg.style.color = 'var(--danger-color)';
                        errorMsg.style.fontSize = '0.875rem';
                        errorMsg.style.marginTop = '0.25rem';
                        field.insertAdjacentElement('afterend', errorMsg);
                    }
                    
                    errorMsg.textContent = `${fieldName} is required.`;
                } else {
                    field.classList.remove('error');
                    const errorMsg = field.nextElementSibling;
                    if (errorMsg && errorMsg.classList.contains('error-message')) {
                        errorMsg.remove();
                    }
                }
            });
            
            if (!isValid) {
                event.preventDefault();
            }
        });
    });
    
    // Custom dropdown behavior
    const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
    
    dropdownToggles.forEach(function(toggle) {
        toggle.addEventListener('click', function(event) {
            event.preventDefault();
            const dropdown = this.nextElementSibling;
            dropdown.classList.toggle('show');
            
            // Close other open dropdowns
            dropdownToggles.forEach(function(otherToggle) {
                if (otherToggle !== toggle) {
                    const otherDropdown = otherToggle.nextElementSibling;
                    if (otherDropdown.classList.contains('show')) {
                        otherDropdown.classList.remove('show');
                    }
                }
            });
        });
    });
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(event) {
        dropdownToggles.forEach(function(toggle) {
            const dropdown = toggle.nextElementSibling;
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });
    });
    
    // Modal handling
    const modalTriggers = document.querySelectorAll('[data-toggle="modal"]');
    
    modalTriggers.forEach(function(trigger) {
        trigger.addEventListener('click', function(event) {
            event.preventDefault();
            const modalId = this.getAttribute('data-target');
            const modal = document.querySelector(modalId);
            
            if (modal) {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
                
                // Close modal when clicking the close button
                const closeButtons = modal.querySelectorAll('[data-dismiss="modal"]');
                closeButtons.forEach(function(button) {
                    button.addEventListener('click', function() {
                        modal.style.display = 'none';
                        document.body.style.overflow = '';
                    });
                });
                
                // Close modal when clicking outside
                modal.addEventListener('click', function(e) {
                    if (e.target === modal) {
                        modal.style.display = 'none';
                        document.body.style.overflow = '';
                    }
                });
            }
        });
    });
    
    // Dynamic forms (adding fields)
    const addFieldButtons = document.querySelectorAll('.add-field');
    
    addFieldButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const fieldContainer = this.previousElementSibling;
            const fieldTemplate = fieldContainer.querySelector('.field-template');
            
            if (fieldTemplate) {
                const newField = fieldTemplate.cloneNode(true);
                newField.classList.remove('field-template');
                newField.style.display = '';
                
                // Clear input values
                const inputs = newField.querySelectorAll('input, select, textarea');
                inputs.forEach(function(input) {
                    input.value = '';
                });
                
                // Add remove button
                const removeButton = document.createElement('button');
                removeButton.type = 'button';
                removeButton.classList.add('btn', 'btn-danger', 'remove-field');
                removeButton.textContent = 'Remove';
                removeButton.addEventListener('click', function() {
                    newField.remove();
                });
                
                newField.appendChild(removeButton);
                fieldContainer.appendChild(newField);
            }
        });
    });
});
