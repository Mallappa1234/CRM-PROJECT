from django import forms
from django.contrib.auth.models import User
from .models import Ticket, TicketReply, TicketCategory
from customers.models import Customer

# Create default ticket categories if they don't exist
default_categories = ["Bug", "Feature Request", "General Inquiry"]
for category in default_categories:
    TicketCategory.objects.get_or_create(name=category)

class TicketForm(forms.ModelForm):
    customer = forms.ModelChoiceField(
        queryset=Customer.objects.filter(status='active'),
        required=True
    )
    assigned_to = forms.ModelChoiceField(
        queryset=User.objects.filter(userprofile__role__in=['admin', 'support']),
        required=False
    )
    category = forms.ModelChoiceField(
        queryset=TicketCategory.objects.all(),
        required=True,
        empty_label="Select Category"
    )
    
    class Meta:
        model = Ticket
        fields = ['subject', 'customer', 'category', 'priority', 'status', 'description', 'assigned_to']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }

class TicketReplyForm(forms.ModelForm):
    class Meta:
        model = TicketReply
        fields = ['message', 'is_internal']
        widgets = {
            'message': forms.Textarea(attrs={'rows': 3}),
        }

class TicketUpdateForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ['status', 'priority', 'assigned_to']

class TicketSearchForm(forms.Form):
    search = forms.CharField(required=False, label='', 
                           widget=forms.TextInput(attrs={'placeholder': 'Search tickets...'}))
    status = forms.ChoiceField(required=False, choices=[('', 'All Statuses')] + list(Ticket.STATUS_CHOICES))
    priority = forms.ChoiceField(required=False, choices=[('', 'All Priorities')] + list(Ticket.PRIORITY_CHOICES))
    category = forms.ModelChoiceField(
        queryset=TicketCategory.objects.all(),
        required=False,
        empty_label="All Categories"
    )
