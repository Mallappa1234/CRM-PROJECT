from django.contrib import admin
from .models import Ticket, TicketReply, TicketCategory

@admin.register(TicketCategory)
class TicketCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name',)

class TicketReplyInline(admin.TabularInline):
    model = TicketReply
    extra = 0

@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ('subject', 'customer', 'status', 'priority', 'category', 'assigned_to', 'created_at')
    list_filter = ('status', 'priority', 'category', 'created_at')
    search_fields = ('subject', 'description', 'customer__name')
    inlines = [TicketReplyInline]
    date_hierarchy = 'created_at'

@admin.register(TicketReply)
class TicketReplyAdmin(admin.ModelAdmin):
    list_display = ('ticket', 'created_by', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('message', 'ticket__subject')
    date_hierarchy = 'created_at'
