from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.contrib import messages

from .models import Ticket, TicketReply
from .forms import TicketForm, TicketReplyForm, TicketUpdateForm, TicketSearchForm

@login_required
def ticket_list(request):
    form = TicketSearchForm(request.GET)
    tickets = Ticket.objects.all()
    
    if form.is_valid():
        search_query = form.cleaned_data.get('search')
        status_filter = form.cleaned_data.get('status')
        priority_filter = form.cleaned_data.get('priority')
        category_filter = form.cleaned_data.get('category')
        
        if search_query:
            tickets = tickets.filter(
                Q(subject__icontains=search_query) | 
                Q(description__icontains=search_query) | 
                Q(customer__name__icontains=search_query)
            )
        
        if status_filter:
            tickets = tickets.filter(status=status_filter)
            
        if priority_filter:
            tickets = tickets.filter(priority=priority_filter)
            
        if category_filter:
            tickets = tickets.filter(category=category_filter)
    
    context = {
        'tickets': tickets,
        'form': form,
    }
    return render(request, 'support/ticket_list.html', context)

@login_required
def ticket_detail(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)
    replies = ticket.replies.all()
    reply_form = TicketReplyForm()
    update_form = TicketUpdateForm(instance=ticket)
    
    context = {
        'ticket': ticket,
        'replies': replies,
        'reply_form': reply_form,
        'update_form': update_form,
    }
    return render(request, 'support/ticket_detail.html', context)

@login_required
def ticket_create(request):
    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.created_by = request.user  # If you track creator
            ticket.save()
            messages.success(request, 'Ticket created successfully.')
            return redirect('support:ticket_list')
    else:
        form = TicketForm()
    return render(request, 'support/ticket_form.html', {
        'form': form,
        'title': 'Create Ticket'
    })

@login_required
def ticket_update(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)
    
    if request.method == 'POST':
        form = TicketUpdateForm(request.POST, instance=ticket)
        if form.is_valid():
            form.save()
            messages.success(request, 'Ticket updated successfully.')
            return redirect('support:ticket_detail', pk=ticket.pk)
    else:
        form = TicketUpdateForm(instance=ticket)
    
    return render(request, 'support/ticket_update.html', {
        'form': form,
        'ticket': ticket
    })

@login_required
def ticket_delete(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)
    
    if request.method == 'POST':
        ticket.delete()
        messages.success(request, 'Ticket deleted successfully.')
        return redirect('support:ticket_list')
    
    return render(request, 'support/ticket_confirm_delete.html', {
        'ticket': ticket
    })

@login_required
def add_ticket_reply(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)
    
    if request.method == 'POST':
        form = TicketReplyForm(request.POST)
        if form.is_valid():
            reply = form.save(commit=False)
            reply.ticket = ticket
            reply.created_by = request.user
            reply.save()
            
            # Update ticket status if not closed or resolved
            if ticket.status not in [Ticket.STATUS_CLOSED, Ticket.STATUS_RESOLVED]:
                if reply.is_internal:
                    ticket.status = Ticket.STATUS_IN_PROGRESS
                else:
                    ticket.status = Ticket.STATUS_WAITING
                ticket.save()
            
            messages.success(request, 'Reply added successfully.')
            return redirect('support:ticket_detail', pk=ticket.pk)
    else:
        form = TicketReplyForm()
    
    return render(request, 'support/ticket_reply_form.html', {
        'form': form,
        'ticket': ticket
    })