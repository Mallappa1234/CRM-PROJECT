# customers/models.py
from django.db import models
from django.conf import settings

class Customer(models.Model):
    STATUS_ACTIVE = 'active'
    STATUS_INACTIVE = 'inactive'
    STATUS_LEAD = 'lead'

    STATUS_CHOICES = [
        (STATUS_ACTIVE, 'Active'),
        (STATUS_INACTIVE, 'Inactive'),
        (STATUS_LEAD, 'Lead'),
    ]

    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True, null=True)
    company = models.CharField(max_length=100, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    website = models.URLField(blank=True, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=STATUS_LEAD)
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_customers'
    )

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['-created_at']

class Interaction(models.Model):
    TYPE_CALL = 'call'
    TYPE_EMAIL = 'email'
    TYPE_MEETING = 'meeting'
    TYPE_NOTE = 'note'

    INTERACTION_TYPES = [
        (TYPE_CALL, 'Phone Call'),
        (TYPE_EMAIL, 'Email'),
        (TYPE_MEETING, 'Meeting'),
        (TYPE_NOTE, 'Note'),
    ]

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='interactions')
    interaction_type = models.CharField(max_length=10, choices=INTERACTION_TYPES)
    notes = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True
    )

    def __str__(self):
        return f"{self.get_interaction_type_display()} with {self.customer.name}"

    class Meta:
        ordering = ['-created_at']