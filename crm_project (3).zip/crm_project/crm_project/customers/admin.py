from django.contrib import admin
from .models import Customer, Interaction

class InteractionInline(admin.TabularInline):
    model = Interaction
    extra = 1

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'company', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('name', 'email', 'company')
    inlines = [InteractionInline]
    date_hierarchy = 'created_at'

@admin.register(Interaction)
class InteractionAdmin(admin.ModelAdmin):
    list_display = ('customer', 'interaction_type', 'created_at', 'created_by')
    list_filter = ('interaction_type', 'created_at')
    search_fields = ('customer__name', 'notes')
    date_hierarchy = 'created_at'
