from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.contrib import messages

from .models import Customer, Interaction
from .forms import CustomerForm, InteractionForm, CustomerSearchForm

@login_required
def customer_list(request):
    form = CustomerSearchForm(request.GET)
    customers = Customer.objects.all()
    
    if form.is_valid():
        search_query = form.cleaned_data.get('search')
        status_filter = form.cleaned_data.get('status')
        
        if search_query:
            customers = customers.filter(
                Q(name__icontains=search_query) | 
                Q(email__icontains=search_query) | 
                Q(company__icontains=search_query)
            )
        
        if status_filter:
            customers = customers.filter(status=status_filter)
    
    context = {
        'customers': customers,
        'form': form,
    }
    return render(request, 'customers/customer_list.html', context)

@login_required
def customer_detail(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    interactions = customer.interactions.all()
    
    context = {
        'customer': customer,
        'interactions': interactions,
        'interaction_form': InteractionForm(),
    }
    return render(request, 'customers/customer_detail.html', context)

@login_required
def customer_create(request):
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            customer = form.save(commit=False)
            customer.created_by = request.user
            customer.save()
            messages.success(request, 'Customer created successfully.')
            return redirect('customers:customer_detail', pk=customer.pk)
    else:
        form = CustomerForm()
    
    return render(request, 'customers/customer_form.html', {
        'form': form,
        'title': 'Add Customer'
    })

@login_required
def customer_update(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    
    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            messages.success(request, 'Customer updated successfully.')
            return redirect('customers:customer_detail', pk=customer.pk)
    else:
        form = CustomerForm(instance=customer)
    
    return render(request, 'customers/customer_form.html', {
        'form': form,
        'customer': customer,
        'title': 'Edit Customer'
    })

@login_required
def customer_delete(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    
    if request.method == 'POST':
        customer.delete()
        messages.success(request, 'Customer deleted successfully.')
        return redirect('customers:customer_list')
    
    return render(request, 'customers/customer_confirm_delete.html', {
        'customer': customer
    })

@login_required
def add_interaction(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    
    if request.method == 'POST':
        form = InteractionForm(request.POST)
        if form.is_valid():
            interaction = form.save(commit=False)
            interaction.customer = customer
            interaction.created_by = request.user
            interaction.save()
            messages.success(request, 'Interaction added successfully.')
            return redirect('customers:customer_detail', pk=customer.pk)
    else:
        form = InteractionForm()
    
    return render(request, 'customers/add_interaction.html', {
        'form': form,
        'customer': customer
    })
