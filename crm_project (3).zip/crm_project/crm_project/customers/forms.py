from django import forms
from .models import Customer, Interaction

class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['name', 'email', 'phone', 'company', 'address', 'website', 'status', 'notes']
        widgets = {
            'notes': forms.Textarea(attrs={'rows': 3}),
            'address': forms.Textarea(attrs={'rows': 2}),
        }

class InteractionForm(forms.ModelForm):
    class Meta:
        model = Interaction
        fields = ['interaction_type', 'notes']
        widgets = {
            'notes': forms.Textarea(attrs={'rows': 3}),
        }

class CustomerSearchForm(forms.Form):
    search = forms.CharField(required=False, label='', 
                             widget=forms.TextInput(attrs={'placeholder': 'Search customers...'}))
    status = forms.ChoiceField(required=False, choices=[('', 'All Statuses')] + list(Customer.STATUS_CHOICES))
