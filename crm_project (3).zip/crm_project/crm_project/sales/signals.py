from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
from accounts.models import UserProfile
from django.db import connection

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    """Create a user profile for new users if it doesn't exist"""
    if created:
        with connection.cursor() as cursor:
            tables = connection.introspection.table_names()
            if 'accounts_userprofile' in tables:
                UserProfile.objects.get_or_create(user=instance, defaults={'role': 'sales'})
