from django.contrib import admin
from .models import Lead, Opportunity, SalesStage

@admin.register(SalesStage)
class SalesStageAdmin(admin.ModelAdmin):
    list_display = ('name', 'order', 'is_won', 'is_lost')
    list_editable = ('order', 'is_won', 'is_lost')
    search_fields = ('name',)

@admin.register(Lead)
class LeadAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'company', 'source', 'status', 'assigned_to', 'created_at')
    list_filter = ('source', 'status', 'created_at')
    search_fields = ('name', 'email', 'company')
    date_hierarchy = 'created_at'

@admin.register(Opportunity)
class OpportunityAdmin(admin.ModelAdmin):
    list_display = ('name', 'customer', 'value', 'stage', 'expected_close_date', 'assigned_to')
    list_filter = ('stage', 'expected_close_date')
    search_fields = ('name', 'customer__name')
    date_hierarchy = 'created_at'
