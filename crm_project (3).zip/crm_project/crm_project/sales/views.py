from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.contrib import messages

from .models import Lead, Opportunity, SalesStage
from customers.models import Customer
from .forms import (
    LeadForm, LeadSearchForm, 
    OpportunityForm, OpportunitySearchForm,
    ConvertLeadForm
)

# Lead views
@login_required
def lead_list(request):
    form = LeadSearchForm(request.GET)
    leads = Lead.objects.all()
    
    if form.is_valid():
        search_query = form.cleaned_data.get('search')
        status_filter = form.cleaned_data.get('status')
        source_filter = form.cleaned_data.get('source')
        
        if search_query:
            leads = leads.filter(
                Q(name__icontains=search_query) | 
                Q(email__icontains=search_query) | 
                Q(company__icontains=search_query)
            )
        
        if status_filter:
            leads = leads.filter(status=status_filter)
            
        if source_filter:
            leads = leads.filter(source=source_filter)
    
    context = {
        'leads': leads,
        'form': form,
    }
    return render(request, 'sales/lead_list.html', context)

@login_required
def lead_detail(request, pk):
    lead = get_object_or_404(Lead, pk=pk)
    convert_form = ConvertLeadForm()
    
    context = {
        'lead': lead,
        'convert_form': convert_form
    }
    return render(request, 'sales/lead_detail.html', context)

@login_required
def lead_create(request):
    if request.method == 'POST':
        form = LeadForm(request.POST)
        if form.is_valid():
            lead = form.save(commit=False)
            lead.created_by = request.user
            lead.save()
            messages.success(request, 'Lead created successfully.')
            return redirect('sales:lead_detail', pk=lead.pk)
    else:
        form = LeadForm()
    
    return render(request, 'sales/lead_form.html', {
        'form': form,
        'title': 'Add Lead'
    })

@login_required
def lead_update(request, pk):
    lead = get_object_or_404(Lead, pk=pk)
    
    if request.method == 'POST':
        form = LeadForm(request.POST, instance=lead)
        if form.is_valid():
            form.save()
            messages.success(request, 'Lead updated successfully.')
            return redirect('sales:lead_detail', pk=lead.pk)
    else:
        form = LeadForm(instance=lead)
    
    return render(request, 'sales/lead_form.html', {
        'form': form,
        'lead': lead,
        'title': 'Edit Lead'
    })

@login_required
def lead_delete(request, pk):
    lead = get_object_or_404(Lead, pk=pk)
    
    if request.method == 'POST':
        lead.delete()
        messages.success(request, 'Lead deleted successfully.')
        return redirect('sales:lead_list')
    
    return render(request, 'sales/lead_confirm_delete.html', {
        'lead': lead
    })

@login_required
def convert_lead(request, pk):
    lead = get_object_or_404(Lead, pk=pk)
    
    if request.method == 'POST':
        form = ConvertLeadForm(request.POST)
        
        if form.is_valid():
            # Create or update customer
            customer, created = Customer.objects.get_or_create(
                email=lead.email,
                defaults={
                    'name': lead.name,
                    'phone': lead.phone,
                    'company': lead.company,
                    'status': Customer.STATUS_ACTIVE,
                    'created_by': request.user
                }
            )
            
            # Create opportunity if selected
            if form.cleaned_data.get('create_opportunity'):
                # Get the first stage
                try:
                    first_stage = SalesStage.objects.all().order_by('order').first()
                except SalesStage.DoesNotExist:
                    first_stage = None
                
                if first_stage:
                    Opportunity.objects.create(
                        name=form.cleaned_data.get('opportunity_name') or f"Opportunity for {customer.name}",
                        customer=customer,
                        stage=first_stage,
                        value=form.cleaned_data.get('value') or 0,
                        expected_close_date=form.cleaned_data.get('expected_close_date'),
                        assigned_to=lead.assigned_to,
                        created_by=request.user
                    )
            
            # Update lead status
            lead.status = Lead.STATUS_CONVERTED
            lead.save()
            
            messages.success(request, f"Lead converted to {'a new' if created else 'an existing'} customer successfully.")
            return redirect('customers:customer_detail', pk=customer.pk)
    else:
        form = ConvertLeadForm()
    
    return render(request, 'sales/convert_lead.html', {
        'form': form,
        'lead': lead
    })

# Opportunity views
@login_required
def opportunity_list(request):
    form = OpportunitySearchForm(request.GET)
    opportunities = Opportunity.objects.all()
    
    if form.is_valid():
        search_query = form.cleaned_data.get('search')
        stage_filter = form.cleaned_data.get('stage')
        
        if search_query:
            opportunities = opportunities.filter(
                Q(name__icontains=search_query) | 
                Q(customer__name__icontains=search_query)
            )
        
        if stage_filter:
            opportunities = opportunities.filter(stage_id=stage_filter)
    
    context = {
        'opportunities': opportunities,
        'form': form,
    }
    return render(request, 'sales/opportunity_list.html', context)

@login_required
def opportunity_detail(request, pk):
    opportunity = get_object_or_404(Opportunity, pk=pk)
    
    context = {
        'opportunity': opportunity,
    }
    return render(request, 'sales/opportunity_detail.html', context)

@login_required
def opportunity_create(request):
    if request.method == 'POST':
        form = OpportunityForm(request.POST)
        if form.is_valid():
            opportunity = form.save(commit=False)
            opportunity.created_by = request.user
            opportunity.save()
            messages.success(request, 'Opportunity created successfully.')
            return redirect('sales:opportunity_detail', pk=opportunity.pk)
    else:
        form = OpportunityForm()
    
    return render(request, 'sales/opportunity_form.html', {
        'form': form,
        'title': 'Add Opportunity'
    })

@login_required
def opportunity_update(request, pk):
    opportunity = get_object_or_404(Opportunity, pk=pk)
    
    if request.method == 'POST':
        form = OpportunityForm(request.POST, instance=opportunity)
        if form.is_valid():
            form.save()
            messages.success(request, 'Opportunity updated successfully.')
            return redirect('sales:opportunity_detail', pk=opportunity.pk)
    else:
        form = OpportunityForm(instance=opportunity)
    
    return render(request, 'sales/opportunity_form.html', {
        'form': form,
        'opportunity': opportunity,
        'title': 'Edit Opportunity'
    })

@login_required
def opportunity_delete(request, pk):
    opportunity = get_object_or_404(Opportunity, pk=pk)
    
    if request.method == 'POST':
        opportunity.delete()
        messages.success(request, 'Opportunity deleted successfully.')
        return redirect('sales:opportunity_list')
    
    return render(request, 'sales/opportunity_confirm_delete.html', {
        'opportunity': opportunity
    })
