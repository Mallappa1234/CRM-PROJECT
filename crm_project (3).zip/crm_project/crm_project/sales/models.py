from django.db import models
from django.conf import settings
from customers.models import Customer

class SalesStage(models.Model):
    name = models.CharField(max_length=50)
    order = models.PositiveSmallIntegerField(default=0)
    is_won = models.BooleanField(default=False)
    is_lost = models.BooleanField(default=False)
    
    def __str__(self):
        return self.name
    
    class Meta:
        ordering = ['order']

class Lead(models.Model):
    STATUS_NEW = 'new'
    STATUS_CONTACTED = 'contacted'
    STATUS_QUALIFIED = 'qualified'
    STATUS_UNQUALIFIED = 'unqualified'
    STATUS_CONVERTED = 'converted'
    
    STATUS_CHOICES = [
        (STATUS_NEW, 'New'),
        (STATUS_CONTACTED, 'Contacted'),
        (STATUS_QUALIFIED, 'Qualified'),
        (STATUS_UNQUALIFIED, 'Unqualified'),
        (STATUS_CONVERTED, 'Converted'),
    ]
    
    SOURCE_WEBSITE = 'website'
    SOURCE_REFERRAL = 'referral'
    SOURCE_SOCIAL = 'social'
    SOURCE_EMAIL = 'email'
    SOURCE_CALL = 'call'
    SOURCE_EXHIBITION = 'exhibition'
    SOURCE_OTHER = 'other'
    
    SOURCE_CHOICES = [
        (SOURCE_WEBSITE, 'Website'),
        (SOURCE_REFERRAL, 'Referral'),
        (SOURCE_SOCIAL, 'Social Media'),
        (SOURCE_EMAIL, 'Email Campaign'),
        (SOURCE_CALL, 'Cold Call'),
        (SOURCE_EXHIBITION, 'Exhibition/Event'),
        (SOURCE_OTHER, 'Other'),
    ]
    
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True, null=True)
    company = models.CharField(max_length=100, blank=True, null=True)
    source = models.CharField(max_length=20, choices=SOURCE_CHOICES, default=SOURCE_OTHER)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_NEW)
    notes = models.TextField(blank=True, null=True)
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_leads'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_leads'
    )
    
    def __str__(self):
        return self.name
    
    class Meta:
        ordering = ['-created_at']

class Opportunity(models.Model):
    name = models.CharField(max_length=100)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='opportunities')
    stage = models.ForeignKey(SalesStage, on_delete=models.PROTECT)
    value = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    expected_close_date = models.DateField(blank=True, null=True)
    products_interested = models.TextField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_opportunities'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_opportunities'
    )
    
    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name_plural = 'Opportunities'
        ordering = ['-created_at']

class OpportunityStage(models.Model):
    name = models.CharField(max_length=100)
    is_won = models.BooleanField(default=False)
    is_lost = models.BooleanField(default=False)

    def __str__(self):
        return self.name
