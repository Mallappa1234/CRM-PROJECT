from django import forms
from django.contrib.auth.models import User
from .models import Lead, Opportunity, OpportunityStage, SalesStage
from customers.models import Customer

class LeadForm(forms.ModelForm):
    assigned_to = forms.ModelChoiceField(
        queryset=User.objects.filter(userprofile__role__in=['admin', 'sales']),
        required=False
    )
    
    class Meta:
        model = Lead
        fields = ['name', 'email', 'phone', 'company', 'source', 'status', 'notes', 'assigned_to']
        widgets = {
            'notes': forms.Textarea(attrs={'rows': 3}),
        }

class LeadSearchForm(forms.Form):
    search = forms.CharField(required=False, label='', 
                            widget=forms.TextInput(attrs={'placeholder': 'Search leads...'}))
    status = forms.ChoiceField(required=False, choices=[('', 'All Statuses')] + list(Lead.STATUS_CHOICES))
    source = forms.ChoiceField(required=False, choices=[('', 'All Sources')] + list(Lead.SOURCE_CHOICES))

class OpportunityForm(forms.ModelForm):
    customer = forms.ModelChoiceField(
        queryset=Customer.objects.filter(status__in=['active', 'lead']),
        required=True
    )
    assigned_to = forms.ModelChoiceField(
        queryset=User.objects.filter(userprofile__role__in=['admin', 'sales']),
        required=False
    )
    stage = forms.ModelChoiceField(
        queryset=SalesStage.objects.all(),
        required=True,
        empty_label="Select Stage"
    )
    
    class Meta:
        model = Opportunity
        fields = ['name', 'customer', 'stage', 'value', 'expected_close_date', 'products_interested', 'notes', 'assigned_to']
        widgets = {
            'expected_close_date': forms.DateInput(attrs={'type': 'date'}),
            'notes': forms.Textarea(attrs={'rows': 3}),
            'products_interested': forms.Textarea(attrs={'rows': 2}),
        }

class OpportunitySearchForm(forms.Form):
    search = forms.CharField(required=False, label='', 
                            widget=forms.TextInput(attrs={'placeholder': 'Search opportunities...'}))
    stage = forms.ChoiceField(required=False)

    def __init__(self, *args, **kwargs):
        from .models import SalesStage
        super().__init__(*args, **kwargs)
        stage_choices = [('', 'All Stages')] + [(stage.id, stage.name) for stage in SalesStage.objects.all()]
        self.fields['stage'].choices = stage_choices

class ConvertLeadForm(forms.Form):
    create_opportunity = forms.BooleanField(initial=True, required=False, label="Create opportunity")
    opportunity_name = forms.CharField(max_length=100, required=False)
    expected_close_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), required=False)
    value = forms.DecimalField(max_digits=12, decimal_places=2, required=False)
